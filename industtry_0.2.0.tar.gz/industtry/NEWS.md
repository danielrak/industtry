# industtry 0.2.0

- Enhancements of short docs. 
- Add long docs. 
- Polish. 

# industtry 0.1.0

Dev enchancements : 

- Add examples and tests as far as possible. 
- Correction of warnings and notes. 
- Before complete documentation. 
