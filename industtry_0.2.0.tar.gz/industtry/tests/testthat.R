library(testthat)
library(industtry)

test_check("industtry")
