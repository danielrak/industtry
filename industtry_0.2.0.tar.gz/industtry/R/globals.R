globalVariables(unique(c(
  "origin", "destination",
  ".", "datasets", "nvar", "nobs",
  "to_convert", "idvarsdupl")))
